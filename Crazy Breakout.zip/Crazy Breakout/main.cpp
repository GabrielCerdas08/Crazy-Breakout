#include <SFML/Graphics.hpp>
#include <time.h>
#include <iostream>
#include <string>
#include <sstream>
#include <bits/stdc++.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <cstring>

using std::cout; using std::cin;
using std::endl; using std::string;

using namespace std;
using namespace sf;



int second();

int main(){
    srand(time(0));
    RenderWindow menu(VideoMode(473,581), "Menu");
    menu.setFramerateLimit(60);


    while (menu.isOpen())
    {
       Event a;
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            menu.close();
            second();

       }
       while (menu.pollEvent(a))
       {
         if (a.type == Event::Closed)
             menu.close();
       }


       menu.display();

    }

    return 0;


}

int swin(){
    srand(time(0));
    RenderWindow win(VideoMode(100, 100), "You win");
    win.setFramerateLimit(60);

    Texture t1;

    t1.loadFromFile("Images/youWin.png");

    Sprite sBackground(t1);
    sBackground.setPosition(0, 0);
    sBackground.setScale(100,100);


    while (win.isOpen())
    {
       Event c;
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            win.close();
            main();

       }
       while (win.pollEvent(c))
       {
         if (c.type == Event::Closed)
             win.close();
       }

       win.draw(sBackground);


       win.display();

    }

    return 0;


}

int slose(){
    srand(time(0));
    RenderWindow lose(VideoMode(100, 100), "You Lose");
    lose.setFramerateLimit(60);

    Texture t1;

    t1.loadFromFile("Images/youLoose.png");

    Sprite sBackground(t1);
    sBackground.setPosition(0, 0);
    sBackground.setScale(100,100);


    while (lose.isOpen())
    {
       Event b;
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            lose.close();
            main();

       }
       while (lose.pollEvent(b))
       {
         if (b.type == Event::Closed)
             lose.close();
       }

       lose.draw(sBackground);


       lose.display();

    }

    return 0;


}

int second()
{
    srand(time(0));

    RenderWindow app(VideoMode(473,581), "Crazy Breakout!");
    int Frame = 45;
    app.setFramerateLimit(Frame);

    Texture t1,t2,t3,t4,t5,t6,t7,t8;
    t1.loadFromFile("Images/block01.png");
    t2.loadFromFile("Images/background.jpg");
    t3.loadFromFile("Images/ball.png");
    t4.loadFromFile("Images/paddle.png");
    t5.loadFromFile("Images/block02.png");
    t6.loadFromFile("Images/block03.png");
    t7.loadFromFile("Images/block04.png");
    t8.loadFromFile("Images/block05.png");

    sf::Font font;
    if(!font.loadFromFile(("arial/Arialn.ttf"))){
        std::cout << "Error font" << std::endl;
        system("pause");
    }


    Sprite sBackground(t2), sBall(t3), sPaddle(t4), sback(t7), sleft(t7), srigth(t7);

    int x_scale=2;
    int y_scale=1;

    sPaddle.setScale(x_scale, y_scale);
    sPaddle.setPosition(200,550);
    sBackground.setPosition(0, 0);

    sleft.setScale(1,1);
    sleft.setPosition(43, 485);

    srigth.setScale(1,1);
    srigth.setPosition(430, 485);

    sback.setScale(430,1);
    sback.setPosition(41.5, 583);


    int Puntos = 0;
    int balls=3;
    bool deep;





    sf::Text score;
    score.setFont(font);
    score.setCharacterSize(24);
    score.setFillColor(sf::Color::Red);
    score.setStyle(sf::Text::Bold);
    score.setPosition(370, 50);

    sf::Text ball;
    ball.setFont(font);
    ball.setCharacterSize(24);
    ball.setFillColor(sf::Color::Red);
    ball.setStyle(sf::Text::Bold);
    ball.setPosition(250, 50);

    sf::Text surprise;
    surprise.setFont(font);
    surprise.setCharacterSize(10);
    surprise.setFillColor(sf::Color::Red);
    surprise.setStyle(sf::Text::Bold);
    surprise.setPosition(80, 55);






    Sprite block0[1000];
    int n0=0;
    for (int i0=10;i0<=10;i0++)
    for (int j0=10;j0<=10;j0++)
      {
         block0[n0].setTexture(t1);
         block0[n0].setPosition(-100, 0);
         n0++;
      }

    //Normal block properties//
    Sprite block[1000];
    int n=0;
    for (int i=1;i<=10;i++)
    for (int j=8;j<=10;j++)
      {
         block[n].setTexture(t1);
         block[n].setPosition(i*43,j*38);
         n++;
      }
    float dx=6, dy=5;
    float x=200, y=500;
    float x_ball=200, y_ball=540;

    //Second Block properties//
    Sprite block_sec[1000];

    int nsecond=0;
    for (int i2=1;i2<=10;i2++)
    for (int j2=8;j2<=10;j2++)
      {
         block_sec[nsecond].setTexture(t5);
         block_sec[nsecond].setPosition(i2*43,j2*28);
         nsecond++;
      }

    float dx_sec=6, dy_sec=5;
    float x_sec=200, y_sec=200;

    int Block_second_counter=0;

    //Third block properties//
    Sprite block_third[1000];
    int nthird=0;
    for (int i3=1;i3<=10;i3++)
    for (int j3=9;j3<=10;j3++)
      {
         block_third[nthird].setTexture(t6);
         block_third[nthird].setPosition(i3*43,j3*20);
         nthird++;
      }
    float dx_third=6, dy_third=5;
    float x_third=200, y_third=200;

    //Fourth block properties//
    Sprite block_fourth[1000];
    int nfourth=0;
    for (int i8=1;i8<=10;i8++)
    for (int j8=10;j8<=10;j8++)
      {
         block_fourth[nfourth].setTexture(t8);
         block_fourth[nfourth].setPosition(i8*43,j8*13);
         nfourth++;
      }
    float dx_fourth=6, dy_fourth=5;
    float x_fourth=200, y_fourth=200;


    //Deep Block  properties//
    Sprite block_deep[1000];
    int ndeep=0;
    for (int i4=10;i4<=10;i4++)
    for (int j4=10;j4<=10;j4++)
      {
         block_deep[ndeep].setTexture(t7);
         block_deep[ndeep].setPosition(430, 485);
         ndeep++;
      }
    float dx_deep=6, dy_deep=5;
    float x_deep=200, y_deep=200;

    //Deep Block2  properties//
    Sprite block_deep2[1000];
    int ndeep2=0;
    for (int i5=10;i5<=10;i5++)
    for (int j5=10;j5<=10;j5++)
      {
         block_deep2[ndeep2].setTexture(t7);
         block_deep2[ndeep2].setPosition(43, 485);
         ndeep2++;
      }
    float dx_deep2=6, dy_deep2=5;
    float x_deep2=200, y_deep2=200;

    //Deep Block3  properties//
    Sprite block_deep3[1000];
    int ndeep3=0;
    for (int i6=10;i6<=10;i6++)
    for (int j6=10;j6<=10;j6++)
      {
         block_deep3[ndeep3].setTexture(t7);
         block_deep3[ndeep3].setPosition(i6*0,j6*57);
         block_deep3[ndeep3].setScale(600, 400);
         ndeep3++;
      }
    float dx_deep3=6, dy_deep3=5;
    float x_deep3=200, y_deep3=200;

    //Deep Block4  properties//
    Sprite block_deep4[1000];
    int ndeep4=0;
    for (int i7=1;i7<=10;i7++)
    for (int j7=10;j7<=10;j7++)
      {
         block_deep4[ndeep4].setTexture(t7);
         block_deep4[ndeep4].setPosition(i7*43,j7*10);
         ndeep4++;
      }
    float dx_deep4=6, dy_deep4=5;
    float x_deep4=200, y_deep4=200;


    //Cycle//
    while (app.isOpen())
    {
       Event e;
       while (app.pollEvent(e))
       {
         if (e.type == Event::Closed)
             app.close();
       }

    std::ostringstream score1;
    score1<<Puntos;
    string s = score1.str();
    score.setString(s);

    std::ostringstream balls1;
    balls1<<balls;
    string s2 = balls1.str();
    ball.setString(s2);

    string surprise1;

    if (Puntos==50){
        x_scale=3;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

    if (Puntos==100){
        x_scale=1;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Encogimiento";
        surprise.setString(surprise1);
    }

    if (Puntos==200){
        x_scale=2;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

        if (Puntos==300){
        x_scale=1;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Encogimiento";
        surprise.setString(surprise1);
    }

        if (Puntos==450){
        x_scale=2;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

        //if (Puntos==210){
        //Frame=  60;
        //surprise1 = "+Velocidad";
        //surprise.setString(surprise1);
    //}

        //if (Puntos==510){
        //Frame=  45;
        //surprise1 = "-Velocidad";
        //surprise.setString(surprise1);
        //}




    //Normal Block collision//
    int hints[30];
    x+=dx;
    for (int i=0;i<n;i++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block[i].getGlobalBounds()))
             {
                hints[i]++;
                if(hints[i]==1){
                        block[i].setPosition(-100,0);
                        Puntos = Puntos + 10;
                        cout<<Puntos<<endl;
                        }



                dx=-dx;

        }


    y+=dy;
    for (int i=0;i<n;i++)

        if ( FloatRect(x+3,y+3,6,6).intersects(block[i].getGlobalBounds()) )
             {
                hints[i]++;

                if(hints[i]==1){
                        block[i].setPosition(-100,0);
                        Puntos = Puntos + 10;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }




    if (x<43 || x>473)  dx=-dx;
    if (y<0 || y>600)  dy=-dy;


    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy=-(rand()%5+2);


    //Second Block collision//
    int hints2[30];
    x_sec+=dx_sec;
    for (int i2=0;i2<nsecond;i2++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_sec[i2].getGlobalBounds()) )
            {
                hints2[i2]++;
                if(hints2[i2]==3){
                    block_sec[i2].setPosition(-100,0);
                    Puntos = Puntos + 15;
                    cout<<Puntos<<endl;
                }
                dx=-dx;

            }
    y_sec+=dy_sec;
    for (int i2=0;i2<nsecond;i2++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_sec[i2].getGlobalBounds()) )
            {

                hints2[i2]++;
                if(hints2[i2]==4){
                        block_sec[i2].setPosition(-100,0);
                        Puntos = Puntos + 15;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }
    if (x_sec<43 || x_sec>473)  dx_sec=-dx;
    if (y_sec<0 || y_sec>600)  dy_sec=-dy;


    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy=-(rand()%5+2);


    //Third Block Collision//
    int hints3[30];
    x_third+=dx_third;
    for (int i3=0;i3<nthird;i3++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_third[i3].getGlobalBounds()) )
             {
                hints3[i3]++;
                if(hints3[i3]==5){
                        block_third[i3].setPosition(-100,0);
                        Puntos = Puntos + 20;
                        cout<<Puntos<<endl;
                }
                dx=-dx;
            }


    y_third+=dy_third;
    for (int i3=0;i3<nthird;i3++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_third[i3].getGlobalBounds()) )
             {
                hints3[i3]++;

                if(hints3[i3]==6){
                        block_third[i3].setPosition(-100,0);
                        Puntos = Puntos + 20;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }


    if (x_third<43 || x_third>473)  dx_third=-dx_third;
    if (y_third<0 || y_third>600)  dy_third=-dy_third;


    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy_third=-(rand()%5+2);

    //Fourth Block Collision//
    int hints8[30];
    x_fourth+=dx_fourth;
    for (int i8=0;i8<nfourth;i8++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_fourth[i8].getGlobalBounds()) )
             {
                hints8[i8]++;
                if(Puntos>=1150){
                        block_third[i8].setPosition(-100,0);
                        Puntos = Puntos + 30;
                        cout<<Puntos<<endl;
                        }
                dx=-dx;
                }

    y_fourth+=dy_fourth;
    for (int i8=0;i8<nfourth;i8++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_fourth[i8].getGlobalBounds()) )
             {
                hints8[i8]++;
                if(Puntos>=1150){
                        block_third[i8].setPosition(-100,0);
                        Puntos = Puntos + 30;
                        cout<<Puntos<<endl;
                        }
                dy=-dy;

                 }


    if (x_fourth<43 || x_fourth>473)  dx_fourth=-dx_fourth;
    if (y_fourth<0 || y_fourth>600)  dy_fourth=-dy_fourth;


    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy_third=-(rand()%5+2);


    //Deep Block3 collision//
    x_deep3+=dx_deep3;
    for (int i6=0;i6<ndeep3;i6++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep3[i6].getGlobalBounds()) )
             {
                 dx=-dx;
                 sBall.setPosition(200,500);
                 balls=balls-1;
                 x_scale=x_scale-0.5;
                 sPaddle.setScale(x_scale, y_scale);
                 cout<<x_scale<<endl;

                 //cout<<balls<<endl;
                 }

    y_deep3+=dy_deep3;
    for (int i6=0;i6<ndeep3;i6++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep3[i6].getGlobalBounds()) )
             {
                 dy=-dy;
                 sBall.setPosition(200,500);
                 }

    if (x_deep3<43 || x_deep3>473)  dx_deep3=-dx_deep3;
    if (y_deep3<0 || y_deep3>600)  dy_deep3=-dy_deep3;

    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy_deep=-(rand()%5+2);


    //Deep Block4 collision//
    x_deep4+=dx_deep4;
    for (int i7=0;i7<ndeep4;i7++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep4[i7].getGlobalBounds()) )
             {dx=-dx;}

    y_deep4+=dy_deep4;
    for (int i7=0;i7<ndeep4;i7++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep4[i7].getGlobalBounds()) )
             {dy=-dy;}

    if (x_deep4<43 || x_deep4>473)  dx_deep4=-dx_deep4;
    if (y_deep4<0 || y_deep4>600)  dy_deep4=-dy_deep4;

    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy_deep=-(rand()%5+2);


    //Paddle movement//
    if (Keyboard::isKeyPressed(Keyboard::Right)) sPaddle.move(10,0);
    if (Keyboard::isKeyPressed(Keyboard::Left)) sPaddle.move(-10,0);
    if (Keyboard::isKeyPressed(Keyboard::Up)) sPaddle.rotate(-5.f);
    if (Keyboard::isKeyPressed(Keyboard::Down)) sPaddle.rotate(5.f);





    sBall.setPosition(x, y);

    app.clear();
    app.draw(sBackground);
    app.draw(sBall);
    app.draw(sPaddle);
    app.draw(score);
    app.draw(ball);
    app.draw(surprise);
    app.draw(sback);
    //app.draw(srigth);
    //p.draw(sleft);


    for (int i=0;i<n;i++)
     app.draw(block[i]);

    for (int i2=0;i2<nsecond;i2++)
     app.draw(block_sec[i2]);

    for (int i3=0;i3<nsecond;i3++)
     app.draw(block_third[i3]);

    for (int i6=0;i6<nsecond;i6++)
     app.draw(block_deep3[i6]);

    for (int i7=0;i7<nsecond;i7++)
     app.draw(block_deep4[i7]);

    for (int i8=0;i8<nfourth;i8++)
     app.draw(block_fourth[i8]);

    for (int i0=0;i0<n0;i0++)
     app.draw(block0[i0]);


     if (balls==0){
        app.close();
        slose();
     }

    if (x_scale<1){
        app.close();
        slose();

     }

    if (Puntos==1450){
        app.close();
        swin();
    }




    app.display();
    }





  return 0;
}


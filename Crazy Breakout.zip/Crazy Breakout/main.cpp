//Import all libraries
#include <SFML/Graphics.hpp>
#include <time.h>
#include <iostream>
#include <string>
#include <sstream>
#include <bits/stdc++.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <cstring>
#include <SFML/Network.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <cstdlib>
#include <iostream>
#include <unistd.h>

//Int to string method
using std::cout; using std::cin;
using std::endl; using std::string;

using namespace std;
using namespace sf;


//Naming the second function to use it in main function
int second();

//! \brief This is the main function, it shows the menu and calls the game function when enter hey is press
//!
//! \param anyone
//! \param anyone
//! \return 0
//!
//!
int main(){

    //Giving main characteristics to the menu Frame
    srand(time(0));
    RenderWindow menu(VideoMode(500,500), "Menu");
    menu.setFramerateLimit(60);
    Texture t1;
    t1.loadFromFile("Images/menu.png");

    Sprite sBackground(t1);
    sBackground.setPosition(0, 0);

    //Defining the menu frame cycle
    while (menu.isOpen())
    {
       Event a;
       //Passing to the game frame
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            menu.close();
            second();
       }
       while (menu.pollEvent(a))
       {
         if (a.type == Event::Closed)
             menu.close();
       }
       menu.draw(sBackground);
       menu.display();
    }
    return 0;


}

//Defining the win window in a function
//! \brief This is win function, it shows the win frame and calls the menu function when you finish the game in a win condition
//!
//! \param anyone
//! \param anyone
//! \return 0
//!
//!
int swin(){
    //Giving main characteristics to the win Frame
    srand(time(0));
    RenderWindow win(VideoMode(100, 100), "You win");
    win.setFramerateLimit(60);

    //Import image
    Texture t1;
    t1.loadFromFile("Images/youWin.png");
    Sprite sBackground(t1);
    sBackground.setPosition(0, 0);

    //Defining the win frame cycle
    while (win.isOpen())
    {
       Event c;
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            win.close();
            main();
       }
       while (win.pollEvent(c))
       {
         if (c.type == Event::Closed)
             win.close();
       }
       win.draw(sBackground);
       win.display();
    }
    return 0;


}

//Defining the lose window in a function
//! \brief This is lose function, it shows the lose frame and calls the menu function when you finish the game in a lose condition
//!
//! \param anyone
//! \param anyone
//! \return 0
//!
//!

int slose(){
    //Giving main characteristics to the lose Frame
    srand(time(0));
    RenderWindow lose(VideoMode(100, 100), "You Lose");
    lose.setFramerateLimit(60);

    //Loading image
    Texture t1;
    t1.loadFromFile("Images/youLoose.png");

    Sprite sBackground(t1);
    sBackground.setPosition(0, 0);

    //Defining the lose frame cycle
    while (lose.isOpen())
    {
       Event b;
       if (Keyboard::isKeyPressed(Keyboard::Enter)){
            lose.close();
            main();
       }
       while (lose.pollEvent(b))
       {
         if (b.type == Event::Closed)
             lose.close();
       }
       lose.draw(sBackground);
       lose.display();
    }
    return 0;
}

//Defining the game window in a function
//! \brief This is game function, it shows the game frame and hear is where all the logic game is, it is in charge of all the events in the game and calls the win or lose frame depending of the situation
//!
//! \param anyone
//! \param anyone
//! \return 0
//!
//!
int second()

{
    //Giving the main characteristics to the game Frame
    srand(time(0));
    RenderWindow app(VideoMode(473,581), "Crazy Breakout!");
    int Frame=45;
    app.setFramerateLimit(Frame);

    //Loading all the images
    Texture t1,t2,t3,t4,t5,t6,t7,t8;
    t1.loadFromFile("Images/block01.png");
    t2.loadFromFile("Images/background.jpg");
    t3.loadFromFile("Images/ball.png");
    t4.loadFromFile("Images/paddle.png");
    t5.loadFromFile("Images/block02.png");
    t6.loadFromFile("Images/block03.png");
    t7.loadFromFile("Images/block04.png");
    t8.loadFromFile("Images/block05.png");

    //Defining the font for the labels
    sf::Font font;
    if(!font.loadFromFile(("Font/Arialn.ttf"))){
        std::cout << "Error font" << std::endl;
        system("pause");
    }

    //Generating the sprites
    Sprite sBackground(t2), sBall(t3), sPaddle(t4), sback(t7), sleft(t7), srigth(t7);

    //Defining integers for paddle scale
    int x_scale=2;
    int y_scale=1;

    //Paddle characteristics
    sPaddle.setScale(x_scale, y_scale);
    sPaddle.setPosition(200,550);
    //Background characteristics
    sBackground.setPosition(0, 0);
    //Rebound block characteristics
    sleft.setScale(1,1);
    sleft.setPosition(43, 485);
    //Rebound block characteristics
    srigth.setScale(1,1);
    srigth.setPosition(430, 485);
    //Rebound block characteristics
    sback.setScale(430,1);
    sback.setPosition(41.5, 583);

    //Defining integers for game fuction
    int Puntos = 0;
    int balls=3;
    int ballspeed;

    //DEFINING LABELS IN GAME FRAME

    //Score label characteristics
    sf::Text score;
    score.setFont(font);
    score.setCharacterSize(24);
    score.setFillColor(sf::Color::Red);
    score.setStyle(sf::Text::Bold);
    score.setPosition(370, 50);
    //Balls label characteristics
    sf::Text ball;
    ball.setFont(font);
    ball.setCharacterSize(24);
    ball.setFillColor(sf::Color::Red);
    ball.setStyle(sf::Text::Bold);
    ball.setPosition(250, 50);
    //Surprise label characteristics
    sf::Text surprise;
    surprise.setFont(font);
    surprise.setCharacterSize(10);
    surprise.setFillColor(sf::Color::Red);
    surprise.setStyle(sf::Text::Bold);
    surprise.setPosition(80, 55);

    //DEFINING BLOCKS PROPERTIES

    //Normal block properties
    Sprite block[1000];
    int n=0;
    for (int i=1;i<=10;i++)
    for (int j=8;j<=10;j++)
      {
         block[n].setTexture(t1);
         block[n].setPosition(i*43,j*38);
         n++;
      }
    float dx=6, dy=5;
    float x=200, y=500;
    float x_ball=200, y_ball=540;
    //Double Block properties
    Sprite block_sec[1000];
    int nsecond=0;
    for (int i2=1;i2<=10;i2++)
    for (int j2=8;j2<=10;j2++)
      {
         block_sec[nsecond].setTexture(t5);
         block_sec[nsecond].setPosition(i2*43,j2*28);
         nsecond++;
      }
    float dx_sec=6, dy_sec=5;
    float x_sec=200, y_sec=200;
    //Triple block properties
    Sprite block_third[1000];
    int nthird=0;
    for (int i3=1;i3<=10;i3++)
    for (int j3=9;j3<=10;j3++)
      {
         block_third[nthird].setTexture(t6);
         block_third[nthird].setPosition(i3*43,j3*20);
         nthird++;
      }
    float dx_third=6, dy_third=5;
    float x_third=200, y_third=200;
    //Internal block properties
    Sprite block_fourth[1000];
    int nfourth=0;
    for (int i8=1;i8<=10;i8++)
    for (int j8=10;j8<=10;j8++)
      {
         block_fourth[nfourth].setTexture(t8);
         block_fourth[nfourth].setPosition(i8*43,j8*13);
         nfourth++;
      }
    float dx_fourth=6, dy_fourth=5;
    float x_fourth=200, y_fourth=200;
    //Deep Block properties
    Sprite block_deep[1000];
    int ndeep=0;
    for (int i4=10;i4<=10;i4++)
    for (int j4=10;j4<=10;j4++)
      {
         block_deep[ndeep].setTexture(t7);
         block_deep[ndeep].setPosition(430, 485);
         ndeep++;
      }
    float dx_deep=6, dy_deep=5;
    float x_deep=200, y_deep=200;
    //Deep Block 2  properties
    Sprite block_deep2[1000];
    int ndeep2=0;
    for (int i5=10;i5<=10;i5++)
    for (int j5=10;j5<=10;j5++)
      {
         block_deep2[ndeep2].setTexture(t7);
         block_deep2[ndeep2].setPosition(43, 485);
         ndeep2++;
      }
    float dx_deep2=6, dy_deep2=5;
    float x_deep2=200, y_deep2=200;
    //Deep Block 3  properties
    Sprite block_deep3[1000];
    int ndeep3=0;
    for (int i6=10;i6<=10;i6++)
    for (int j6=10;j6<=10;j6++)
      {
         block_deep3[ndeep3].setTexture(t7);
         block_deep3[ndeep3].setPosition(i6*0,j6*57);
         block_deep3[ndeep3].setScale(600, 400);
         ndeep3++;
      }
    float dx_deep3=6, dy_deep3=5;
    float x_deep3=200, y_deep3=200;
    //Deep Block 4  properties
    Sprite block_deep4[1000];
    int ndeep4=0;
    for (int i7=1;i7<=10;i7++)
    for (int j7=10;j7<=10;j7++)
      {
         block_deep4[ndeep4].setTexture(t7);
         block_deep4[ndeep4].setPosition(i7*43,j7*10);
         ndeep4++;
      }
    float dx_deep4=6, dy_deep4=5;
    float x_deep4=200, y_deep4=200;


    //Cycle for the game Frame
    while (app.isOpen())
    {
       Event e;
       while (app.pollEvent(e))
       {
         if (e.type == Event::Closed)
             app.close();
       }

    //Defining the score int as string
    std::ostringstream score1;
    score1<<Puntos;
    string s = score1.str();
    //Giving the string to the label
    score.setString(s);

    //Defining the balls int as string
    std::ostringstream balls1;
    balls1<<balls;
    string s2 = balls1.str();
    //Gibing the string to the label
    ball.setString(s2);

    //Defining the surprise string
    string surprise1;

    //++SPEED
    if (Puntos==0){
        ballspeed=5;
    }
    if (Puntos==100){
        ballspeed=6;

    }
    if (Puntos==200){
        ballspeed=7;

    }
    if (Puntos==300){
        ballspeed=7;

    }
    if (Puntos==400){
        ballspeed=8;


    }
    if (Puntos==500){
        ballspeed=9;


    }
    if (Puntos==600){
        ballspeed=10;

    }
    if (Puntos==700){
        ballspeed=11;
    }

    //SURPRISES
    if (Puntos==50){
        x_scale=3;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

    if (Puntos==100){
        x_scale=1;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Encogimiento";
        surprise.setString(surprise1);
    }

    if (Puntos==200){
        x_scale=2;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

        if (Puntos==300){
        x_scale=1;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Encogimiento";
        surprise.setString(surprise1);
    }

        if (Puntos==450){
        x_scale=2;
        sPaddle.setScale(x_scale, y_scale);
        surprise1 = "Agrandamiento";
        surprise.setString(surprise1);
    }

        if (Puntos==210){
        ballspeed=  15;
        surprise1 = "+Velocidad";
        surprise.setString(surprise1);
    }
        if (Puntos==270){
        ballspeed=  5;
        surprise1 = "";
        surprise.setString(surprise1);
    }

        if (Puntos==510){
        Frame=  1;
        surprise1 = "-Velocidad";
        surprise.setString(surprise1);
    }
        if (Puntos==570){
        ballspeed=  5;
        surprise1 = "";
        surprise.setString(surprise1);
    }




    //Normal Block collision//
    int hints[30];
    //Collision in X
    x+=dx;
    for (int i=0;i<n;i++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block[i].getGlobalBounds()))
             {
                hints[i]++;
                if(hints[i]==1){
                        block[i].setPosition(-100,0);
                        Puntos = Puntos + 10;
                        cout<<Puntos<<endl;
                        }
                dx=-dx;
        }
    //Collision in y
    y+=dy;
    for (int i=0;i<n;i++)

        if ( FloatRect(x+3,y+3,6,6).intersects(block[i].getGlobalBounds()) )
             {
                hints[i]++;

                if(hints[i]==1){
                        block[i].setPosition(-100,0);
                        Puntos = Puntos + 10;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }
    //Defining the ball position after collision
    if (x<43 || x>473)  dx=-dx;
    if (y<0 || y>600)  dy=-dy;
    if ( FloatRect(x,y,12,12).intersects(sPaddle.getGlobalBounds()) ) dy=-(rand()%ballspeed+2);


    //Double Block collision
    int hints2[30];
    //Collision in x
    x_sec+=dx_sec;
    for (int i2=0;i2<nsecond;i2++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_sec[i2].getGlobalBounds()) )
            {
                hints2[i2]++;
                if(hints2[i2]==3){
                    block_sec[i2].setPosition(-100,0);
                    Puntos = Puntos + 15;
                    cout<<Puntos<<endl;
                }
                dx=-dx;
            }
    //Collision in y
    y_sec+=dy_sec;
    for (int i2=0;i2<nsecond;i2++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_sec[i2].getGlobalBounds()) )
            {

                hints2[i2]++;
                if(hints2[i2]==4){
                        block_sec[i2].setPosition(-100,0);
                        Puntos = Puntos + 15;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }
    //Defining the ball position after collision
    if (x_sec<43 || x_sec>473)  dx_sec=-dx;
    if (y_sec<0 || y_sec>600)  dy_sec=-dy;


    //Triple Block Collision
    int hints3[30];
    //Collision in x
    x_third+=dx_third;
    for (int i3=0;i3<nthird;i3++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_third[i3].getGlobalBounds()) )
             {
                hints3[i3]++;
                if(hints3[i3]==5){
                        block_third[i3].setPosition(-100,0);
                        Puntos = Puntos + 20;
                        cout<<Puntos<<endl;
                }
                dx=-dx;
            }
    //Collision in y
    y_third+=dy_third;
    for (int i3=0;i3<nthird;i3++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_third[i3].getGlobalBounds()) )
             {
                hints3[i3]++;

                if(hints3[i3]==6){
                        block_third[i3].setPosition(-100,0);
                        Puntos = Puntos + 20;
                        cout<<Puntos<<endl;
                }
                dy=-dy;
            }
    //Defining the ball position after collision
    if (x_third<43 || x_third>473)  dx_third=-dx_third;
    if (y_third<0 || y_third>600)  dy_third=-dy_third;

    //Fourth Block Collision
    int hints8[30];
    //Collision in x
    x_fourth+=dx_fourth;
    for (int i8=0;i8<nfourth;i8++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_fourth[i8].getGlobalBounds()) )
             {
                hints8[i8]++;
                if(Puntos>=1150){
                        block_third[i8].setPosition(-100,0);
                        Puntos = Puntos + 30;
                        cout<<Puntos<<endl;
                        }
                dx=-dx;
                }
    //Collision in y
    y_fourth+=dy_fourth;
    for (int i8=0;i8<nfourth;i8++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_fourth[i8].getGlobalBounds()) )
             {
                hints8[i8]++;
                if(Puntos>=1150){
                        block_third[i8].setPosition(-100,0);
                        Puntos = Puntos + 30;
                        cout<<Puntos<<endl;
                        }
                dy=-dy;
                 }
    //Defining the ball position after collision
    if (x_fourth<43 || x_fourth>473)  dx_fourth=-dx_fourth;
    if (y_fourth<0 || y_fourth>600)  dy_fourth=-dy_fourth;


    //Deep Block 3 collision
    //Collision in x
    x_deep3+=dx_deep3;
    for (int i6=0;i6<ndeep3;i6++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep3[i6].getGlobalBounds()) )
             {
                 dx=-dx;
                 sBall.setPosition(200,500);
                 balls=balls-1;
                 x_scale=x_scale-0.5;
                 sPaddle.setScale(x_scale, y_scale);
                 cout<<x_scale<<endl;
                 }
    //Collision in y
    y_deep3+=dy_deep3;
    for (int i6=0;i6<ndeep3;i6++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep3[i6].getGlobalBounds()) )
             {
                 dy=-dy;
                 sBall.setPosition(200,500);
                 }
    //Defining the ball position after collision
    if (x_deep3<43 || x_deep3>473)  dx_deep3=-dx_deep3;
    if (y_deep3<0 || y_deep3>600)  dy_deep3=-dy_deep3;

    //Deep Block 4 collision
    //Collision in x
    x_deep4+=dx_deep4;
    for (int i7=0;i7<ndeep4;i7++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep4[i7].getGlobalBounds()) )
             {dx=-dx;}
    //Collision in y
    y_deep4+=dy_deep4;
    for (int i7=0;i7<ndeep4;i7++)
        if ( FloatRect(x+3,y+3,6,6).intersects(block_deep4[i7].getGlobalBounds()) )
             {dy=-dy;}
    //Defining the ball position after collision
    if (x_deep4<43 || x_deep4>473)  dx_deep4=-dx_deep4;
    if (y_deep4<0 || y_deep4>600)  dy_deep4=-dy_deep4;



    //Paddle movement
    if (Keyboard::isKeyPressed(Keyboard::Right)) sPaddle.move(10,0);
    if (Keyboard::isKeyPressed(Keyboard::Left)) sPaddle.move(-10,0);
    if (Keyboard::isKeyPressed(Keyboard::Up)) sPaddle.rotate(-5.f);
    if (Keyboard::isKeyPressed(Keyboard::Down)) sPaddle.rotate(5.f);

    //Ball position
    sBall.setPosition(x, y);

    //Drawing all sprites
    app.clear();
    app.draw(sBackground);
    app.draw(sBall);
    app.draw(sPaddle);
    app.draw(score);
    app.draw(ball);
    app.draw(surprise);
    app.draw(sback);
    app.draw(ball);



    //Drawing all blocks
    for (int i=0;i<n;i++)
     app.draw(block[i]);

    for (int i2=0;i2<nsecond;i2++)
     app.draw(block_sec[i2]);

    for (int i3=0;i3<nsecond;i3++)
     app.draw(block_third[i3]);

    for (int i6=0;i6<nsecond;i6++)
     app.draw(block_deep3[i6]);

    for (int i7=0;i7<nsecond;i7++)
     app.draw(block_deep4[i7]);

    for (int i8=0;i8<nfourth;i8++)
     app.draw(block_fourth[i8]);

     //Losing for balls
     if (balls==0){
        app.close();
        slose();
     }
     //Losing for paddle size
    if (x_scale<1){
        app.close();
        slose();
     }
     //Winning for points
    if (Puntos==1450){
        app.close();
        swin();
    }

    app.display();
    }

  return 0;
}


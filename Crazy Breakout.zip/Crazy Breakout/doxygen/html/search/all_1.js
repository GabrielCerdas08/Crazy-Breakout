var searchData=
[
  ['second_0',['second',['../main_8cpp.html#aed5657208944fe098e4e5f3380e0a1f9',1,'main.cpp']]],
  ['slose_1',['slose',['../main_8cpp.html#a1be0bfe9df70a8804e5edf7bb7f3ceff',1,'main.cpp']]],
  ['swin_2',['swin',['../main_8cpp.html#abbc0661327817ce0e10ebf257222882d',1,'main.cpp']]]
];
